# 项目说明

## 游戏入口页面（可直接打开）
	／views/index.html

## 游戏资源路径
	/public/css 样式文件
	/public/img  图片相关
	/public/js	 js相关


	/public/css/main.css 游戏样式
	/public/js/main.js 游戏脚本

## 配置(api主机地址，账号)
	／public/js/common.js(这里配置)

	主机地址：API_ROOT_URL
	账号标识：'ca9bcb33-6e8b-4506-a8a6-24d7f54ed1af'

## 请求方法
	api_post(method, type, callback);